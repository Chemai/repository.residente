# - * - codificación: utf-8 - * -

"""^ SECCIÓN 1:
    Esto debería estar en la parte superior de su código para declarar el tipo de texto
    formato que estás usando. Sin esto, puede encontrar algunos editores de texto guardar
    en un formato incompatible y esto puede hacer que el seguimiento de errores extremadamente
    ¡confuso! Más información aquí: https://www.python.org/dev/peps/pep-0263/
"""

# ------------------------------------------------- ---------------

"""
    SECCIÓN 2:
    Aquí es donde pondría los detalles de su licencia, la licencia GPL3
    es el más común de usar, ya que facilita a los demás a tenedor
    y mejora tu código Si estás reutilizando el código de otros SIEMPRE
    primero verifique la licencia, NO se permite la eliminación de licencias y usted
    en general, debe mantener la misma licencia utilizada en el trabajo original
    (verifique los detalles de la licencia ya que algunos difieren).

    Aunque no todas las licencias lo requieren (algunos lo hacen, otros no),
    siempre debe dar crédito al autor (es) original (es). Alguien puede haber gastado
    meses si no años en el código así que realmente es lo mínimo que puede hacer si
    eliges usar su trabajo como base para el tuyo.
"""

# Licencia: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Addon: Complemento My Python Koding
# Autor: Agregue su nombre aquí

# ------------------------------------------------- ---------------

"""
     SECCION 3:
     Estas son sus importaciones globales, cualquier módulo del que necesite importar código
     se agregan aquí. Verá un puñado de las importaciones más comunes a continuación.
"""

import os 			#accesos a los comandos del sistema operativo
import urlparse 	# divide la ruta del directorio, es mucho más fácil importar esto que codificarlo nosotros mismos
import xbmc 		# the base xbmc functions, casi todos los add-on van a necesitar al menos una función de aquí
import xbmcaddon 	# pull información específica del complemento como configuración, id, fanart, etc.
import xbmcgui 		# gui, contiene cosas como crear ventanas emergentes de diálogo
import xbmcplugin 	# contiene las funciones necesarias para crear complementos de estilo de estructura de directorios (complementos)

# (*) = Estos módulos requieren el repositorio noobsandnerds para ser instalado
import koding # (*) un framework para un desarrollo fácil de complementos, esta plantilla se usará junto con este módulo.

from koding import Add_Dir # Al importar algo como esto, no necesitamos usar <module>. <function> para llamarlo,
                            # en su lugar, puede usar el nombre de la función, en este caso Add_Dir ().

from koding import route, Run # Estas son importaciones esenciales que nos permiten abrir directorios y navegar a través del complemento.

# ------------------------------------------------- ---------------

"""
    SECCIÓN 4:
	Estas son nuestras variables globales, cualquier cosa que establezcamos aquí puede 
	ser accedida por cualquiera de  nuestras funciones más adelante. Por favor, tenga 
	en mente que si cambia el valor de una variable global desde dentro de una función,
	el valor volverá a la valor establecido aquí una vez que la función se haya completado.
"""
addon_id		= xbmcaddon.Addon (). getAddonInfo ('id') 	# Agarra nuestro ID de complemento
dialog			= xbmcgui.Dialog () # Un comando de mensaje de diálogo básico
home_folder		= xbmc.translatePath ('special: // home /') # Convierta la ruta especial de la carpeta de inicio de Kodi a la ruta física
addon_folder	= os.path.join (home_folder, 'addons') 		# Únete a nuestra carpeta de arriba con 'addons' para que tengamos un enlace a nuestra carpeta de complementos
art_path		= os.path.join (addon_folder, addon_id) 	# Unir la carpeta addons con el addon_id, lo usaremos como una carpeta de arte básica
debug			= koding.Addon_Setting ('debug') 			# Obtenga la configuración de nuestro modo de depuración en la configuración de complementos

# ------------------------------------------------- ---------------

"""
    SECCION 5:
    Agregue nuestras funciones personalizadas aquí, es MUY importante que vayan en esta sección
    como el código en la sección 6 se basa en estas funciones. Si ese código intenta ejecutarse
    antes de declarar estas funciones, el complemento fallará.

    Notarás que cada función aquí tiene un decorador encima (una línea de código @rute ()),
    esto asigna un modo a la función para que pueda invocarse con Add_Dir y también le dice
    el código por el que enviar los parámetros. Por ejemplo, notará la función Main_Menu ()
    hemos asignado el modo "principal" - esto significa que si alguna vez queremos obtener 
	Add_Dir para abrir eso función que acabamos de utilizar el modo "principal". 
	Esta función particular no requiere ningún extra parámetros a enviar, pero si observa la función 
	Testing () verá que enviamos a través de 2 parámetros diferentes (url y descripción), si miras la 
	función Add_Dir en Main_Menu () verás que los hemos enviado como un diccionario. 
	Usando ese mismo formato puede enviar a través de tantos params diferentes como desees
"""
# ------------------------------------------------- ----------
# EDITAR ESTA FUNCIÓN MAIN_MENU () - ¡ESTO ES DIVERTIDO CON EL QUE JUGAR!
# ------------------------------------------------- ----------
@route (modo = "principal")
def Main_Menu ():

# Mostrar solo tutoriales de koding si el modo de depuración está habilitado en la configuración de complemento
    if debug=='true':
        Add_Dir(name='KODING TUTORIALS', url='', mode='tutorials', folder=True, icon=os.path.join(art_path,'icon.png'), fanart=os.path.join(art_path,'fanart.jpg'))

    Add_Dir(name='DIÁLOGO DE PRUEBA', url='{"my_text":"Mi primer Add-on[CR]Woohooo!!!","my_desc":"test description"}', mode='testing', folder=False, icon=os.path.join(art_path,'icon.png'), fanart=os.path.join(art_path,'fanart.jpg'))


# Una vez que haya jugado con lo anterior, intente descomentar cada una de las siguientes líneas una a una.
# Después de descomentar una línea, vuelva a ejecutar el complemento para ver sus cambios.

    # Add_Dir (name = 'OPEN FOLDER - MODO DE PRUEBA', url = 'test_mode', mode = 'carpeta_abierta', carpeta = Verdadero, icon = os.path.join (art_path, 'icon.png'), fanart = os. path.join (art_path, 'fanart.jpg'))
    # Add_Dir (name = 'OPEN FOLDER - NO URL', url = '', mode = 'abrir_carpeta', carpeta = Verdadero, icon = os.path.join (art_path, 'icon.png'), fanart = os.path .join (art_path, 'fanart.jpg'))
    # Add_Dir (name = 'VIDEO EJEMPLOS', url = '', mode = 'video_examples', carpeta = Verdadero, icon = os.path.join (art_path, 'icon.png'), fanart = os.path.join ( art_path, 'fanart.jpg'), description = 'Un par de videos de prueba para que los vea.', content_type = 'video')
    # Add_Dir (name = 'EJEMPLO DE MÚSICA', url = '', mode = 'music_examples', carpeta = Verdadero, icon = os.path.join (art_path, 'icon.png'), fanart = os.path.join ( art_path, 'fanart.jpg'), content_type = 'canción')

# Esta es nuestra zona de prueba, esto solo llama al modo Test_Function, así que siéntete libre de jugar con el código en esa función.
    # Add_Dir (name = 'TESTING ZONE', url = '{"test1": "esto es", "test2": "algún ejemplo", "test3": "text"}', mode = 'test_function', folder = False, icon = os.path.join (art_path, 'icon.png'), fanart = os.path.join (art_path, 'fanart.jpg'))
 #-----------------------------
@route(mode="test_function", args=["test1","test2","test3"])
def Test_Function(test1, test2, test3):
# Ejemplo de envío de múltiples variables a través de la función Add_Dir
    xbmc.log(test1,2)
    xbmc.log(test2,2)
    xbmc.log(test3,2)
    dialog.ok('CHECK THE LOG','Take a look at your log, you should be able to see the 3 lines of example text we sent through.')
#-----------------------------
@route(mode="open_folder", args=["url"])
def Test_Folder(url):
    if url == 'test_mode':
        dialog.ok('Test Mode','open_folder has been called with the url being "test_mode". When you click OK you should open into and empty folder - this is because folder=True in our Add_Dir()')
    else:
        dialog.ok('TRY THESE EXAMPLES','If you\'ve left the mode as the default you\'ll receive a message explaining the mode does not exist. Feel free to change this to a mode that does exist.')
        Add_Dir(name='EXAMPLE FOLDER', url='', mode='changeme', folder=True, icon=os.path.join(art_path,'icon.png'), fanart=os.path.join(art_path,'fanart.jpg'))
        Add_Dir(name='EXAMPLE ITEM', url='', mode='changeme', folder=False, icon=os.path.join(art_path,'icon.png'), fanart=os.path.join(art_path,'fanart.jpg'))
        Add_Dir(name='EXAMPLE BAD FUNCTION', url='', mode='bad_function', folder=False, icon=os.path.join(art_path,'icon.png'), fanart=os.path.join(art_path,'fanart.jpg'))
#-----------------------------
@route(mode="bad_function")
def Bad_Function():
    if debug != 'true':
        dialog.ok('SET DEBUG TO TRUE','Go into your add-on settings and set debug mode to True then run this again. If debug is set to true we have proper error reporting in place to help your add-on development.')
        koding.Open_Settings(focus='1.1')
    xbmc.log(this_should_error)
#-----------------------------
@route(mode='testing', args=["my_text","my_desc"])
def Testing(my_text,my_desc):
    dialog.ok('TEST','Here are the params we recieved in Testing() function:', 'my_text: [COLOR=dodgerblue]%s[/COLOR]' % my_text,'my_desc: [COLOR=dodgerblue]%s[/COLOR]'%my_desc)
#-----------------------------
@route(mode="video_examples")
def Video_Examples():
    """
A continuación se muestran algunos ejemplos que muestran Add_Dir () con algunas ilustraciones y etiquetas de información enviadas a través del enlace de avance de una película
Obviamente, utilizarías algún tipo de bucle automático para generar automáticamente esta información para listas grandes, pero espero que este ejemplo pueda ayudar
    """
    Add_Dir(name='[COLOR=dodgerblue][TV][/COLOR] Fraggle Rock S03E21', url='episode_dialog', mode='scrape_sites', folder=False, content_type='Video',
        icon='https://images-na.ssl-images-amazon.com/images/M/MV5BNzg0MzQwODY3N15BMl5BanBnXkFtZTgwMjA2OTEwMjE@._V1_SY1000_CR0,0,789,1000_AL_.jpg',
        fanart='https://images-na.ssl-images-amazon.com/images/M/MV5BMjI0MjI4NTEwNV5BMl5BanBnXkFtZTgwMzA4NTQ2MjE@._V1_.jpg',
        info_labels={"season":"03", "episode":"21", "genre":"Kids", "plot":"Get your cares away, worries for another day...", "mpaa":"U"})

    Add_Dir(name='[COLOR=dodgerblue][MOVIE][/COLOR] Trainspotting', url='movie_dialog', mode='scrape_sites', folder=False, content_type='Video',
        icon='https://images-na.ssl-images-amazon.com/images/M/MV5BMzA5Zjc3ZTMtMmU5YS00YTMwLWI4MWUtYTU0YTVmNjVmODZhXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_UX182_CR0,0,182,268_AL_.jpg',
        fanart='https://images-na.ssl-images-amazon.com/images/M/MV5BMTMxNjE3NzU2Nl5BMl5BanBnXkFtZTcwMzI0OTAyNg@@._V1_.jpg',
        info_labels={"originaltitle":"Trainspotting","genre":"crime,british", "plot":"Trainspotting is an awesome movie!", "mpaa":"18", "trailer":"plugin://plugin.video.youtube/play/?video_id=nBKWnAdmJJ8"})
    dialog.ok('CLICK INFO','Try bringing up the info for these items, you should see our artwork and other metadata has been populated.')
#-----------------------------
@route(mode="music_examples")
def Music_Examples():
     """
Este es un ejemplo de agregar una canción, hay muchas posibilidades de que Scaper no encuentre resultados para esta canción,
solo está aquí como ejemplo para mostrar cómo configurar cosas como obras de arte.
     """
    Add_Dir(name='Sally Cinnamon - Stone Roses', url='song_dialog', mode='scrape_sites', folder=False,
        icon='http://images.rapgenius.com/7929026cc89ab0c77669dee5cc323da9.530x528x1.jpg',
        fanart='http://www.flickofthefinger.co.uk/wp-content/uploads/2016/03/the-stone-roses-1.jpg',
        info_labels={"genre":"Rock,Inde,British", "artist":"Stone Roses", "title":"Sally Cinnamon"})
#-----------------------------
@route(mode="scrape_sites", args=["url"])
def Scrape_Sites(list_type):
    """
Esta es una función ficticia, agregaría el código que necesite aquí para captar el contenido.
No utilice esta función para descifrar el contenido infractor de derechos de autor. Si necesita un sitio para probar con
archive.org tiene una buena biblioteca de archivos de música y video de dominio público.
    """
    content = ''
    if list_type == 'movie_dialog':
	        dolog ('Agregue su código para raspar para una película')
    elif list_type == 'episode_dialog':
	        dolog ('Agregue su código para raspar para un programa de televisión')
	elif list_type == 'song_dialog':
	        dolog ('Agrega tu código para raspar una canción')

# Si el artículo devuelto es un diccionario que es genial, sabemos que tenemos una lista para trabajar con
    if koding.Data_Type(content) == 'dict':
        xbmc.log(repr(content),2)
        playback = koding.Play_Video(video=content["url"], showbusy=True)
		
# Puede ser un complemento o una dirección URL directa, de ser así, use la variable list_type.
    elif not list_type.endswith('_dialog'):
        playback = koding.Play_Video(video=list_type, showbusy=True)

# No se ha encontrado nada útil, permite salir de nuevo a la lista
    else:
        return

# Si la reproducción se devolvió como True, fue exitosa, pero si fue False, sabemos que debemos volver a intentar obtener otra fuente

    if not playback:
        if dialog.yesno('PLAYBACK FAILED','The video may have been removed, the web host may have altered their code or this video may not be available in your region. [COLOR=dodgerblue]Would you like to try another source?[/COLOR]'):
            Scrape_Sites(list_type)

# ------------------------------------------------- ---------------

"""
     SECCION 6:
     Esencial si se crean elementos de la lista, esto le dice a kodi que hemos terminado de crear nuestros elementos de la lista.
     La lista no se completará sin esto. En el comando ejecutar, debe establecer el valor predeterminado para
     cualquier ruta en la que desee abrir, en este ejemplo, la ruta "principal" que abre el
     Main_Menu () funciona en la parte superior.
"""
if __name__ == "__main__":
    Run(default='main')
    xbmcplugin.endOfDirectory(int(sys.argv[1]))